from django.shortcuts import render, redirect
from django.http import HttpResponse
import sqlite3, random, datetime


def admin(request):
    return render(request, "Admin.html")


def about(request):
    return render(request, "About.html")



def index(request):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                Uname = user[1]
    return render(request, "Index.html", context={"UserName": Uname})


def info(request, title="", text=""):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                Uname = user[1]
    return render(request, "Info.html", context={"Tit": title, "Txt": text, "UserName": Uname})


def ext(request):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                cursor.execute(f'UPDATE Users SET agent = " " WHERE id = {user[0]};')

        connection.commit()
    return redirect(f'/')

def pet(request, num=0):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                Uname = user[1]

    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Pets')
        pets = cursor.fetchall()
        pits=[]
        for pit in pets:
            pits.append(pit)

        connection.commit()
    return render(request, "Pets.html",
                  context={"NumPet": pits[num][0], "Name": pits[num][1], "KRTKO": pits[num][3], "PetInd": num, "What": pits[num][2], "UserName": Uname})


def Pnext(request, num):
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Pets')
        pets = cursor.fetchall()
        pits=[]
        for pit in pets:
            pits.append(pit)

        connection.commit()
    if num + 1 >= len(pits):
        num1 = 0
    else:
        num1 = num + 1
    return redirect(f'/pet/{num1}/')


def Pback(request, num):
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Pets')
        pets = cursor.fetchall()
        pits=[]
        for pit in pets:
            pits.append(pit)

        connection.commit()
    if num - 1 < 0:
        num1 = len(pits) - 1
    else:
        num1 = num - 1
    return redirect(f'/pet/{num1}/')


def Pwish(request, num):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                Uname = user[1]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Pets')
        pets = cursor.fetchall()
        name=""
        for pit in pets:
            if pit[0] == num:
                sum = float(pit[4])
                name = pit[1]

        connection.commit()
    Sum = request.POST.get("Sum", None)
    Cell = request.POST.get("Text", None)
    user_agent = request.META["HTTP_USER_AGENT"]
    if Sum != None and Sum != "":
        Sum = float(Sum)
        with sqlite3.connect(r'web\static\database\db.db') as connection:
            cursor = connection.cursor()

            cursor.execute('SELECT * FROM Users')
            users = cursor.fetchall()

            for user in users:
                if user[3] == user_agent:
                    ID_u = user[0]
            cursor.execute('INSERT INTO Donats (id_user, id_pet, sum, wish) VALUES (?, ?, ?, ?)', (ID_u, num, Sum, Cell))
            cursor.execute(f"UPDATE Pets SET sum = {Sum+sum} WHERE id = {num};")
            connection.commit()
        return redirect(f'/info/Спасибо за пожертвование/ /')
    return render(request, "Wish.html", context={"NumPet": num, "Name": f"Пожертвование - {name}", "UserName": Uname})


def Pforum(request, num):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                Uname = user[1]
    Mess = request.POST.get("Mess", None)
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Pets')
        pets = cursor.fetchall()
        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                ID_u = user[0]
                Uname = user[1]
        for pit in pets:
            if pit[0] == num:
                name = pit[1]
                data = eval(pit[5])
        if Mess != None and Mess != "":
            date = datetime.datetime.now()
            date = f"{date.day}.{date.month}.{date.year} {date.hour}:{date.minute}"
            data.append([date, ID_u, Mess])
            cursor.execute(f'UPDATE Pets SET forum = "{data}" WHERE id = {num};')
        for user in users:
            for i in range(len(data)):
                if data[i][1] == user[0]:
                    data[i][1] = user[1]
        oni = ""
        ty = ""
        for i in data:
            if i[1] == Uname:
                oni += "        \n<br>"
                ty += f"        \n<p>{i[0]} - {i[1]} - {i[2]}</p>"
            else:
                oni += f"       \n<p>{i[0]} - {i[1]} - {i[2]}</p>"
                ty += f"        \n<br>"
        with open(r"web/templates/call.html","w",encoding="utf-8") as form:
            form.write(f"""<div class="main">
    <div>{ty}
    </div>
    <div>{oni}
    </div>
</div>""")
    return render(request, "Forum.html", context={"NumPet": num, "Name": f"Обсуждение - {name}", "Data": "gh\n\nhj", "UserName": Uname})


def Ptake(request, num):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                Uname = user[1]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Pets')
        pets = cursor.fetchall()
        name=""
        for pit in pets:
            if pit[0] == num:
                name = pit[1]
    FIO = request.POST.get("Fio", None)
    Statys = request.POST.get("Statys", None)
    Home = request.POST.get("Home", None)
    Work = request.POST.get("Work", None)
    Dosyg = request.POST.get("Dosyg", None)
    Allegrik = request.POST.get("Allegrik", None)
    Years = request.POST.get("Years", None)
    user_agent = request.META["HTTP_USER_AGENT"]
    if (FIO != None and FIO != '') and (Statys != None and Statys != '') and (Home != None and Home != '') and (Work != None and Work != ''):
        with sqlite3.connect(r'web\static\database\db.db') as connection:
            cursor = connection.cursor()

            cursor.execute('SELECT * FROM Users')
            users = cursor.fetchall()

            for user in users:
                if user[3] == user_agent:
                    ID_u = user[0]

            cursor.execute('INSERT INTO Applications (id_user, id_pet, years, fio, statys, home, work, hobby, Allergic) '
                           'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                           (ID_u, num, Years, FIO, Statys, Home, Work, Dosyg, Allegrik))

            connection.commit()
        return redirect(f'/info/Заявка отправлена/ /')
    else:
        return render(request, "Take.html", context={"Name": name, "NumPet": num, "UserName": Uname})


def report(request):
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                Uname = user[1]
    return render(request, "Report.html", context={"UserName": Uname})


def RPpet(request):
    pet = request.POST.get("Pet", "None")
    place = request.POST.get("Place", "None")
    user_agent = request.META["HTTP_USER_AGENT"]
    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Report')
        users = cursor.fetchall()

        ids=[]
        for user in users:
            ids.append(user[0])
        ID = random.randint(10000, 99999)
        while ID == ids:
            ID = random.randint(10000, 99999)

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[3] == user_agent:
                ID_u = user[0]

        cursor.execute('INSERT INTO Report (id, usernum, pet, place) VALUES (?, ?, ?, ?)', (ID,ID_u,pet,place))

        connection.commit()
    return redirect('/main/')


def account(request):
    return render(request, "Account.html")


def login(request):
    Login = request.POST.get("WhatUser", None)
    Password = request.POST.get("KeyAccess", None)
    user_agent = request.META["HTTP_USER_AGENT"]
    if Login == None: return redirect('/')
    if Password == None: return redirect('/')

    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        for user in users:
            if user[1] == Login and user[2] == Password:
                cursor.execute(f"UPDATE Users SET agent = '{user_agent}' WHERE id = {user[0]};")
                break
        else:
            return redirect(f'/')
    connection.commit()
    return redirect(f'/main/')


def reg(request):
    return render(request, "Registration.html")


def Rlogin(request):
    print("--------------------------------------------------------------------")
    Login = request.POST.get("User", None)
    Password = request.POST.get("Key", None)
    Email = request.POST.get("Email", "no@email.post")
    Telephone = request.POST.get("Telephone", '+7 (000) 000 00-00')
    Like = request.POST.get("O_like", "None")
    Skill = request.POST.get("O_skills", "None")
    user_agent = request.META["HTTP_USER_AGENT"]

    if Login == None: return redirect('/')
    if Password == None: return redirect('/')

    with sqlite3.connect(r'web\static\database\db.db') as connection:
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Users')
        users = cursor.fetchall()

        ids = []
        for user in users:
            if user[1] == Login: return redirect('/')
            if user[2] == Password: return redirect('/')
            ids.append(user[0])
        ID = random.randint(10000, 99999)
        while ID == ids:
            ID = random.randint(10000, 99999)


        cursor.execute('INSERT INTO Users (id, login, password, agent, email, phone, like, skill) '
                       'VALUES (?, ?, ?, ?, ?, ?, ?, ?)', (ID, Login, Password, user_agent, Email, Telephone, Like, Skill))
        connection.commit()
        return redirect('/main/')
    return redirect('/')
